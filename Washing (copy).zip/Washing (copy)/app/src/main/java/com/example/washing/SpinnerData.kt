package com.example.washing

val tempList = mutableListOf(
    "Nước Lạnh",
    "30",
    "40",
    "60",
    "90"
)
val powerList = mutableListOf(
    "0w/p",
    "400w/p",
    "800w/p",
    "1000w/p",
    "1200w/p"
)
val waterList = mutableListOf(
    "Mức 1",
    "Mức 2",
    "Mức 3",
    "Mặc định",
    "Reset"
)
val softenerList = mutableListOf(
    "Mức 1",
    "Mức 2",
    "Mức 3",
    "Mặc định",
    "Reset"
)
val titelFuntion = mutableListOf(
    "Tự động",
    "Đồ trang sức",
    "Rửa kình"
)
val titelWashingProgram = mutableListOf(
    "Vải bông",
    "Vải bong +",
    "Sợ tổng hợp",
    "Đồ len",
    "Đồ trẻ em",
    "Chăn mềm",
    "Đồ thể thao",
    "Chăn mềm",
    "Đồ thể thao",
    "Chế độ yêu thích",
    "Giặt nhẹ",
    "Giặt hỗn hợp",
    "Vệ sinh lồng giặt",
    "Giặt khử khuẩn",
    "Giặt nhanh 15'",
    "Giặt kỹ",
    "Chỉ vắt",
    "Giữ và vắt"
)