package com.example.washing

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_ultra_sonic_program.*
import kotlinx.android.synthetic.main.fragment_washing_program.*

class UltraSonicProgramFragment : Fragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ultra_sonic_program, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        arguments?.takeIf { it.containsKey(Companion.ARG_OBJECT) }?.apply {
//            textName.text = getInt(Companion.ARG_OBJECT).toString()
        }
        val stringTempAdapter = ImageAdapter(tempList) {
            //on selected
        }
        val stringTitleAdapter = TitleFuntionAdapter(titelFuntion) {
            //on selected
        }
        val myLayoutManager = CenterZoomLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
        val myLayoutManager1 = CenterZoomLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
//        myLayoutManager.reverseLayout = false

        rv_image.apply {
            adapter = stringTempAdapter
            layoutManager = myLayoutManager
        }
        rvTitle.apply {
            adapter = stringTitleAdapter
            layoutManager = myLayoutManager1
        }
    }

    companion object {
        private const val ARG_OBJECT = "object"
    }

}